qemu-system-i386 -cdrom $1
